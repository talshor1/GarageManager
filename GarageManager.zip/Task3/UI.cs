﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ex03.GarageLogic;

namespace Task3
{
    class UI
    {
        internal static void RunProgram()
        {
            PrintMenu();
            int m_CurrentOption = 0;
            GetUserOption(ref m_CurrentOption);
            Console.Clear();
            RunNextOption(m_CurrentOption);
        }

        private static void PrintMenu()
        {
            string Menu = string.Format(@"Hi, Please enter the option you would like to do:

1.)Insert new car to the garage
2.)Check the car numbers in the gargae 
3.)Change specific car situation
4.)Inflate car wheels to the maximum (car number)
5.)Refuel car (car number, fuel type, amount in Liters)
6.)Charge electronic car (car number, minutes to charge)
7.)Get car information (car number)
8.)Exit");
            Console.WriteLine(Menu);
        }

        private static void GetUserOption(ref int m_CurrentOption)
        {
            int optionFromTheUser = 0;
            try
            {
                optionFromTheUser = int.Parse(Console.ReadLine());
            }
            catch(Exception e)
            {
                Console.WriteLine("You didnt enter a number");
            }
            bool isValidInput = true;
            isValidInput = isUserInputValid(optionFromTheUser);
            while (!isValidInput)
            {
                Console.WriteLine("Please make sure to enter a number 1-8, thank you.");
                optionFromTheUser = int.Parse(Console.ReadLine());
                isValidInput = isUserInputValid(optionFromTheUser);
            }

            m_CurrentOption = optionFromTheUser;
        }

        private static bool isUserInputValid(int i_OptionFromTheUser)
        {
            bool userInputValid = true;
            if(i_OptionFromTheUser < 1 || i_OptionFromTheUser > 8)
            {
                userInputValid = false;
            }

            return userInputValid;
        }

        private static void RunNextOption(int i_Option)
        {
            switch (i_Option)
            {
                case 1:
                    {
                        InsertNewVehicle();
                        NewScreen();
                        break;
                    }
                case 2:
                    {
                        Console.Clear();
                        VehicleInTheGarage.ShowVehiclesNumbers();
                        NewScreen();
                        break;
                    }
                case 3:
                    {
                        Console.Clear();
                        CahngeVehicleSituation();
                        NewScreen();
                        break;
                    }
                case 4:
                    {
                        Console.Clear();
                        InflateMax();
                        NewScreen();
                        break;
                    }
                case 5:
                    {
                        Console.Clear();
                        Refuel();
                        NewScreen();
                        break;
                    }
                case 6:
                    {
                        Console.Clear();
                        Refuel();
                        NewScreen();
                        break;
                    }
                case 7:
                    {
                        Console.Clear();
                        ShowVehicleDetails();
                        NewScreen();
                        break;
                    }
                default:
                    {
                        Console.Clear();
                        NewScreen();
                        break;
                    }
            }
        }

        private static void InsertNewVehicle()
        {
            int VehicleType = 0;
            Console.WriteLine(@"Please choose one of the following options:
"+VehicleCreator.GetVehicleOptions());
            GetVehicleOption(ref VehicleType);
            Console.Clear();
            Console.WriteLine(@"please Enter The Following Details:
Vehicel model
Vehicle number
Energy source (Electricity, Soler, Octan95, Octan96, Octan98)
Wheels amount (Motorcycle 2, Car 4, Truck 12)
Wheels producer
Wheels current air pressure
Wheels maximum air pressure
Energy left
Maximum energy");
            switch (VehicleType)
            {
                case (1):
                    {
                        Vehicle newVehicle = FuelVehicleCreator();
                        if(!VehicleInTheGarage.InsertVehicleToGarage(newVehicle))
                        {
                            Console.Clear();
                            Console.WriteLine("Such vehicle already exist press any key to continue");
                            NewScreen();
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("A new Fuel car in the garage! " + newVehicle.VehicleNumber);
                            NewScreen();
                        }
                        break;
                    }
                case (2):
                    {
                        Vehicle newVehicle = ElectricVehicleCreator();
                        if (!VehicleInTheGarage.InsertVehicleToGarage(newVehicle))
                        {
                            Console.Clear();
                            Console.WriteLine("Such vehicle already exist");
                            NewScreen();
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("A new Electric car in the garage! " + newVehicle.VehicleNumber);
                            NewScreen();
                        }
                        break;
                    }
                case (3):
                    {
                        Vehicle newVehicle = FuelMotorcycleCreator();
                        if (!VehicleInTheGarage.InsertVehicleToGarage(newVehicle))
                        {
                            Console.Clear();
                            Console.WriteLine("Such vehicle already exist");
                            NewScreen();
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("A new Fuel Motorcycle in the garage! " + newVehicle.VehicleNumber);
                            NewScreen();
                        }
                        break;
                    }
                case (4):
                    {
                        Vehicle newVehicle = ElectricMotorcycleCreator();
                        if (!VehicleInTheGarage.InsertVehicleToGarage(newVehicle))
                        {
                            Console.Clear();
                            Console.WriteLine("Such vehicle already exist");
                            NewScreen();
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("A new Electric Motorcycle in the garage! " + newVehicle.VehicleNumber);
                            NewScreen();
                        }
                        break;
                    }
                case (5):
                    {
                        Vehicle newVehicle = TruckCreator();
                        if (!VehicleInTheGarage.InsertVehicleToGarage(newVehicle))
                        {
                            Console.Clear();
                            Console.WriteLine("Such vehicle already exist");
                            NewScreen();
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("A new Truck in the garage! " + newVehicle.VehicleNumber);
                            NewScreen();
                        }
                        break;
                    }
                default:
                    {
                        break;
                    }
            }
        }

        private static void GetVehicleOption(ref int m_CurrentOption)
        {
            int optionFromTheUser = 0;
            try
            {
                optionFromTheUser = int.Parse(Console.ReadLine());
            }
            catch(Exception e)
            {
                Console.WriteLine("You didnt enter a number");
            }
            bool isValidInput = true;
            isValidInput = VehicleInputValid(optionFromTheUser);
            while (!isValidInput)
            {
                Console.WriteLine("Please make sure to enter a number 1-5, thank you.");
                optionFromTheUser = int.Parse(Console.ReadLine());
                isValidInput = isUserInputValid(optionFromTheUser);
            }

            m_CurrentOption = optionFromTheUser;
        }

        private static bool VehicleInputValid(int i_OptionFromTheUser)
        {
            bool userInputValid = true;
            if (i_OptionFromTheUser < 1 || i_OptionFromTheUser > 5)
            {
                userInputValid = false;
            }

            return userInputValid;
        }

        private static void PrintDic(Dictionary<string, string> i_VehicleDic)
        {
            foreach (KeyValuePair<string, string> info in i_VehicleDic)
            {
                Console.WriteLine("Key = {0}, Value = {1}", info.Key, info.Value);
            }
        }

        private static Vehicle FuelVehicleCreator()
        {
            string VehicleInfo = VehicleCreator.GetBasicInfo();
            Dictionary<string, string> VehicleDictionary = new Dictionary<string, string>();
            VehicleCreator.BasicDictionaryInitialization(VehicleInfo, VehicleDictionary);
            Console.WriteLine("Please enter doors amount: (2/3/4/5)");
            string DoorsAmount = Console.ReadLine();
            Console.WriteLine("Please enter car colour (Red/Blue/Black/Grey)");
            string CarColour = Console.ReadLine();
            if (!GenericValidation.FuelCarValidation(DoorsAmount, CarColour) || !GenericValidation.CheckBasicInfo(VehicleInfo))
            {
                Console.WriteLine("you didnt enter valid information");
                NewScreen();
            }

            else
            {
                VehicleCreator.initializeFuelCar(VehicleDictionary, DoorsAmount, CarColour);
                Car newFuelCar = new Car(VehicleDictionary);
                return newFuelCar;
            }

            return null;
        }

        private static Vehicle ElectricVehicleCreator()
        {
            string VehicleInfo = VehicleCreator.GetBasicInfo();
            Dictionary<string, string> VehicleDictionary = new Dictionary<string, string>();
            VehicleCreator.BasicDictionaryInitialization(VehicleInfo, VehicleDictionary);
            Console.WriteLine("Please enter doors amount: (2/3/4/5)");
            string DoorsAmount = Console.ReadLine();
            Console.WriteLine("Please enter car colour (Red/Blue/Black/Grey)");
            string CarColour = Console.ReadLine();
            if (!GenericValidation.FuelCarValidation(DoorsAmount, CarColour) ||
                !GenericValidation.CheckBasicInfo(VehicleInfo) ||
                !GenericValidation.ElectricCheck(VehicleInfo)) //check also if the source is electricity
            {
                Console.WriteLine("you didnt enter valid information");
                NewScreen();
            }

            else
            {
                VehicleCreator.initializeElectricCar(VehicleDictionary, DoorsAmount, CarColour);
                Car newElectricCar = new Car(VehicleDictionary);
                return newElectricCar;
            }

            return null;
        }

        private static Vehicle FuelMotorcycleCreator()
        {
            string VehicleInfo = VehicleCreator.GetBasicInfo();
            Dictionary<string, string> VehicleDictionary = new Dictionary<string, string>();
            VehicleCreator.BasicDictionaryInitialization(VehicleInfo, VehicleDictionary);
            Console.WriteLine("Please enter license kind: (A/A1/A2/B)");
            string LicenseKind = Console.ReadLine();
            Console.WriteLine("Please enter engine capacity (numeric value)");
            string EngineCapacity = Console.ReadLine();
            if (!GenericValidation.MotorcycleValidation(LicenseKind, EngineCapacity) ||
                !GenericValidation.CheckBasicInfo(VehicleInfo)) 
            {
                Console.WriteLine("you didnt enter valid information");
                NewScreen();
            }

            else
            {
                VehicleCreator.initializeFuelMotorcycle(VehicleDictionary, LicenseKind, EngineCapacity);
                Motorcycle newFuelMotorcycle = new Motorcycle(VehicleDictionary);
                return newFuelMotorcycle;
            }

            return null;
        }

        private static Vehicle ElectricMotorcycleCreator()
        {
            string VehicleInfo = VehicleCreator.GetBasicInfo();
            Dictionary<string, string> VehicleDictionary = new Dictionary<string, string>();
            VehicleCreator.BasicDictionaryInitialization(VehicleInfo, VehicleDictionary);
            Console.WriteLine("Please enter license kind: (A/A1/A2/B)");
            string licenseKind = Console.ReadLine();
            Console.WriteLine("Please enter engine capacity (numeric value)");
            string engineCapacity = Console.ReadLine();
            if (!GenericValidation.MotorcycleValidation(licenseKind, engineCapacity) ||
                !GenericValidation.CheckBasicInfo(VehicleInfo) ||
                !GenericValidation.ElectricCheck(VehicleInfo)) //check if electric source
            {
                Console.WriteLine("you didnt enter valid information");
                NewScreen();
            }

            else
            {
                VehicleCreator.initializeElectricMotorcycle(VehicleDictionary, licenseKind, engineCapacity);
                Motorcycle newFuelMotorcycle = new Motorcycle(VehicleDictionary);
                return newFuelMotorcycle;
            }

            return null;
        }

        private static Vehicle TruckCreator()
        {
            string VehicleInfo = VehicleCreator.GetBasicInfo();
            Dictionary<string, string> VehicleDictionary = new Dictionary<string, string>();
            VehicleCreator.BasicDictionaryInitialization(VehicleInfo, VehicleDictionary);
            Console.WriteLine("The Truck contains dangerous materials?: (Y/N)");
            string dangerousMaterials = Console.ReadLine();
            Console.WriteLine("Please enter cargo volume (numeric value)");
            string cargoVolume = Console.ReadLine();
            if (!GenericValidation.TruckValidation(dangerousMaterials, cargoVolume) ||
                !GenericValidation.CheckBasicInfo(VehicleInfo))
            {
                Console.WriteLine("you didnt enter valid information");
                NewScreen();
            }

            else
            {
                VehicleCreator.initializeTruck(VehicleDictionary, dangerousMaterials, cargoVolume);
                Truck newFuelMotorcycle = new Truck(VehicleDictionary);
                return newFuelMotorcycle;
            }

            return null;
        }

        private static void CahngeVehicleSituation()
        {
            bool isLegal = true;
            Console.WriteLine("Please enter the vehicle number to change it situation:");
            string vehicleNumber = Console.ReadLine();
            Console.WriteLine("please enter the same situation as you want to change for: (inProcess/finished/payed)");
            string changedSituation = Console.ReadLine();
            if(!Costumer.SituationCheck(changedSituation))
            {
                Console.WriteLine("you entered Wrong situation");
                isLegal = false;
            }

            if(VehicleInTheGarage.CheckIfVehicleExists(vehicleNumber))
            {
                Console.WriteLine("the vehicle number dosent exist in the garage");
                isLegal = false;
            }

            if(!isLegal)
            {
                Console.Clear();
                NewScreen();
            }

            else
            {
                VehicleInTheGarage.SituationChange(vehicleNumber, changedSituation);
                Console.WriteLine(vehicleNumber + " vehicle number, situation changed for: " + changedSituation);
            }
        }

        private static void InflateMax()
        {
            Console.WriteLine("enter vehicle number to infalte for maximum air pressure in the wheels:");
            string i_VehicleNumber = Console.ReadLine();
            if (!VehicleNumberCheck(i_VehicleNumber))
            {
                NewScreen();
            }

            else
            {
                VehicleInTheGarage.InflateMax(i_VehicleNumber);
                Console.WriteLine("now all the wheels of your car is at maximum air pressure");
            }

        }

        private static void Refuel()
        {
            Console.WriteLine("please enter vehicle number:");
            string vehicleNumber = Console.ReadLine();
            if(!VehicleNumberCheck(vehicleNumber))
            {
                NewScreen();
            }

            Console.WriteLine("please enter energy type same as your car (Electricity, Soler, Octan95, Octan96, Octan98)");
            string energyType = Console.ReadLine();
            Console.WriteLine("please enter the amount to add");
            string amountToAdd = Console.ReadLine();
            if(!GenericValidation.CheckIfIntAndPositive(amountToAdd))
            {
                Console.WriteLine("you didnt enter numeric value");
                NewScreen();
            }

            else
            {
                try
                {
                    VehicleInTheGarage.Refuel(vehicleNumber, energyType, amountToAdd);
                }
                catch(Exception e)
                {
                    Console.WriteLine("the process could not be done make sure to select the right energy type");
                    NewScreen();
                }
                Console.Clear();
                Console.WriteLine("your vehicle got refuel!!");
            }

        }

        private static void ShowVehicleDetails()
        {
            Console.WriteLine("please enter vehicle number to see its details:");
            string i_VehicleNumber = Console.ReadLine();
            if (!VehicleNumberCheck(i_VehicleNumber))
            {
                NewScreen();
            }

            else
            {
                VehicleInTheGarage.ShowVehicleDetails(i_VehicleNumber);
            }

        }

        private static bool VehicleNumberCheck(string i_VehicleNumber)
        {
            bool legalNumber = true;
            if (!GenericValidation.CheckIfIntAndPositive(i_VehicleNumber))
            {
                Console.WriteLine("you didnt enter numeric vehicle number, press any key to continue");
                legalNumber = false;
            }

            if (VehicleInTheGarage.CheckIfVehicleExists(i_VehicleNumber))
            {
                Console.WriteLine("the vehicle number dosent exist in the gargae, press any key to continue");
                legalNumber = false;
            }

            return legalNumber;
        }

        public static void NewScreen()
        {
            Console.WriteLine("press any key to continue");
            Console.ReadKey();
            RunProgram();
        }
    }
}
