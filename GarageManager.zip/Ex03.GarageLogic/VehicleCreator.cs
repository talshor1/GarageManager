﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex03.GarageLogic
{
    public class VehicleCreator
    {
        internal enum eSuportedVehicle
        {
            FuelCar,
            ElectricCar,
            FuelMotorcycle,
            ElectricMotorcycle,
            Truck
        }

        public static void initializeFuelCar(Dictionary<string, string> i_VehicleDic, string i_DoorsAmount, string i_CarColour)
        {
            i_VehicleDic.Add("Doors amount", i_DoorsAmount);
            i_VehicleDic.Add("Car colour", i_CarColour);
        }

        public static void initializeElectricCar(Dictionary<string, string> i_VehicleDic, string i_DoorsAmount, string i_CarColour)
        {
            i_VehicleDic.Add("Doors amount", i_DoorsAmount);
            i_VehicleDic.Add("Car colour", i_CarColour);
        }

        public static void initializeFuelMotorcycle(Dictionary<string, string> i_VehicleDic,
            string i_LicenseKind, string i_EngineCapacity)
        {
            i_VehicleDic.Add("License kind", i_LicenseKind);
            i_VehicleDic.Add("Engine capacity", i_EngineCapacity);
        }

        public static void initializeElectricMotorcycle(Dictionary<string, string> i_VehicleDic,
            string i_LicenseKind, string i_EngineCapacity)
        {
            i_VehicleDic.Add("License kind", i_LicenseKind);
            i_VehicleDic.Add("Engine capacity", i_EngineCapacity);
        }

        public static void initializeTruck(Dictionary<string, string> i_VehicleDic, string i_IsDangerous, string i_CargoVolume)
        {
            i_VehicleDic.Add("Dangerous materials", i_IsDangerous);
            i_VehicleDic.Add("Cargo volume", i_CargoVolume);
        }

        public static string GetVehicleOptions()
        {
            StringBuilder suppurtedVehicles = new StringBuilder();
            byte optionsCounter = 1;
            foreach (eSuportedVehicle vehicle in (eSuportedVehicle[])Enum.GetValues(typeof(eSuportedVehicle)))
            {
                suppurtedVehicles.Append(optionsCounter + ".)" + vehicle + " " + Environment.NewLine);
                optionsCounter++;
            }

            return suppurtedVehicles.ToString();
        }

        public static string GetBasicInfo()
        {
            string VehicleInfo = Console.ReadLine();
            return VehicleInfo;
        }

        public static void BasicDictionaryInitialization(string i_VehicleInfoString, Dictionary<string, string> i_VehicleDic)
        {
            string[] VehicleInfo = i_VehicleInfoString.Split(' ');
            i_VehicleDic.Add("Model name", VehicleInfo[0]);
            i_VehicleDic.Add("Vehicle number", VehicleInfo[1]);
            i_VehicleDic.Add("Energy source", VehicleInfo[2]);
            i_VehicleDic.Add("Wheels amount", VehicleInfo[3]);
            i_VehicleDic.Add("Wheels producer", VehicleInfo[4]);
            i_VehicleDic.Add("Energy left", VehicleInfo[5]);
            i_VehicleDic.Add("Maximum energy", VehicleInfo[6]);
            i_VehicleDic.Add("Wheels current air pressure", VehicleInfo[7]);
            i_VehicleDic.Add("Wheels maximum air pressure", VehicleInfo[8]);
        }
    }

}
