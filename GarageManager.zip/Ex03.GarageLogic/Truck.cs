﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex03.GarageLogic
{
    public class Truck : Vehicle
    {
        private bool m_HasDangerousMaterials = false;
        private float m_CargoVolume = 0f;

        public Truck(Dictionary<string, string> i_VehicleInfo) : base(i_VehicleInfo)
        {
            this.m_HasDangerousMaterials = i_VehicleInfo["Dangerous materials"] == "Y";
            this.m_CargoVolume = float.Parse(i_VehicleInfo["Cargo volume"]);
        }

        public float Cargo
        {
            get
            {
                return this.m_CargoVolume;
            }

            set
            {
                this.m_CargoVolume = value;
            }

        }
    }
}
