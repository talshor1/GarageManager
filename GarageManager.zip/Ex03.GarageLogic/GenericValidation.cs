﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex03.GarageLogic
{
    public class GenericValidation
    {
        private const int AmountOfBasicInfo = 9; 
        public static bool CheckBasicInfo(string i_VehicleInfo)
        {
            bool isLegalInfo = true;
            string[] VehicleInfo = i_VehicleInfo.Split(' ');
            if (VehicleInfo.Length != AmountOfBasicInfo) 
            {
                isLegalInfo = false;
            }

            try
            {
                int.Parse(VehicleInfo[1]); //check if the vehicle number is numeric
            }
            catch(FormatException e)
            {
                isLegalInfo = false;
            }

            if (!EnergySource.CheckLegalSource(VehicleInfo[2])) // check energy source validity
            {
                isLegalInfo = false;
            }

            if(!Wheel.CheckWheelsAmountValidity(VehicleInfo[3])) // check wheels validity
            {
                isLegalInfo = false; ;
            }

            for(int i = AmountOfBasicInfo-4 ; i < AmountOfBasicInfo; i ++)
            {
                if (!CheckIfFloatAndPositive(VehicleInfo[i]))
                {
                    isLegalInfo = false;
                }
            }
            return isLegalInfo;
        }

        private static bool CheckIfFloatAndPositive(string i_StringToCheck)
        {
            bool isNumeric = true;
            float numericValue = 0;
            try
            {
                numericValue = float.Parse(i_StringToCheck);
            }
            catch(FormatException e)
            {
                isNumeric = false;
            }

            if(numericValue < 0)
            {
                isNumeric = false;
            }

            return isNumeric;
        }

        public static bool CheckIfIntAndPositive(string i_StringToCheck)
        {
            bool isNumeric = true;
            int numericValue = 0;
            try
            {
                numericValue = int.Parse(i_StringToCheck);
            }
            catch (FormatException e)
            {
                isNumeric = false;
            }

            if (numericValue < 0)
            {
                isNumeric = false;
            }

            return isNumeric;
        }

        public static bool FuelCarValidation(string i_DoorsAmount, string i_CarColour)
        {
            bool isLegal = true;
            int DoorsAmount = 0;
            if(!Car.ColourCheck(i_CarColour))
            {
                isLegal = false;
            }

            try
            {
                DoorsAmount = int.Parse(i_DoorsAmount);
            }
            catch(Exception e)
            {
                isLegal = false;
            }

            if(!Car.DoorsAmountCheck(DoorsAmount))
            {
                isLegal = false;
            }

            return isLegal;
        }

        public static bool ElectricCheck(string i_VehicleInfo)
        {
            bool isElectric = true;
            string[] VehicleInfo = i_VehicleInfo.Split(' ');
            if (VehicleInfo[2] != "Electricity")
            {
                isElectric = false; 
            }

            return isElectric;
        }

        public static bool MotorcycleValidation(string i_LicenseKind, string i_EngineCapacity)
        {
            bool legalMotorcycle = true;
            int engineCapacity = 0;
            legalMotorcycle = Motorcycle.LicenseKindCheck(i_LicenseKind);
            try
            {
                engineCapacity = int.Parse(i_EngineCapacity);
                if(engineCapacity < 0)
                {
                    legalMotorcycle = false;
                }

            }
            catch(FormatException e)
            {
                legalMotorcycle = false;
            }

            return legalMotorcycle;
        }

        public static bool TruckValidation(string i_DangerousMaterials, string i_CargoVolume)
        {
            bool truckValid = true;
            float cargoVolume = 0f;
            if(i_DangerousMaterials != "Y" && i_DangerousMaterials != "N")
            {
                truckValid = false;
            }

            try
            {
                cargoVolume = float.Parse(i_CargoVolume);
                if(cargoVolume < 0)
                {
                    truckValid = false;
                }

            }
            catch(FormatException e)
            {
                truckValid = false;
            }

            return truckValid;
        }

    }
}
