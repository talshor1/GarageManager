﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex03.GarageLogic
{
    public class Car : Vehicle
    {
        public enum eColour
        {
            Red,
            Blue,
            Black,
            Grey
        }

        internal eColour m_CarColour;
        internal int m_DoorsAmount = 0;

        public Car(Dictionary<string, string> i_VehicleInfo) : base(i_VehicleInfo)
        {
            this.m_DoorsAmount = int.Parse(i_VehicleInfo["Doors amount"]);
            this.m_CarColour = (eColour)Enum.Parse(typeof(eColour), i_VehicleInfo["Car colour"]);
        }

        internal static bool DoorsAmountCheck(int i_DoorsAmount)
        {
            bool isLegalDoorsAmount = true;
            if (i_DoorsAmount > 5 || i_DoorsAmount < 2)
            {
                isLegalDoorsAmount = false;
            }

            return isLegalDoorsAmount;
        }

        internal static bool ColourCheck(string i_CarColour)
        {
            bool isLegalColour = true;
            isLegalColour = Enum.GetNames(typeof(Car.eColour)).Contains(i_CarColour);
            return isLegalColour;
        }
    }
}
