﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex03.GarageLogic
{
    public class ValueOutOfRangeException : Exception
    {
        public float m_MaxValue = 0f;
        public float m_MinValue = 0f;
        
        public ValueOutOfRangeException(string message, float i_MinValue, float i_MaxValue) : base(message)
        {
            this.m_MaxValue = i_MaxValue;
            this.m_MinValue = i_MinValue;
        }

        public ValueOutOfRangeException(string message,Exception inner, float i_MinValue, float i_MaxValue) : base(message, inner)
        {
            this.m_MaxValue = i_MaxValue;
            this.m_MinValue = i_MinValue;
        }

        public float MinValue
        {
            get
            {
                return this.m_MinValue;
            }

            set
            {
                this.m_MinValue = value;
            }
        }

        public float MaxValue
        {
            get
            {
                return this.m_MaxValue;
            }

            set
            {
                this.m_MaxValue = value;
            }
        }
    }
}
