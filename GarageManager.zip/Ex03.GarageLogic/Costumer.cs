﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex03.GarageLogic
{
    public class Costumer
    {
        public enum eSituation
        {
            inProcess,
            finished,
            payed
        }


        internal string m_OwnersName = null;
        internal string m_PhoneNumber = null;
        internal Vehicle m_CurrentVehicle = null;
        internal eSituation m_situation;

        public Costumer(Vehicle i_Vehicle, string i_OwnerPrivateName, string i_PhoneNumber)
        {
            m_OwnersName = i_OwnerPrivateName;
            m_PhoneNumber = i_PhoneNumber;
            m_CurrentVehicle = i_Vehicle;
            m_situation = eSituation.inProcess;
        }

        public static bool SituationCheck(string i_Situation)
        {
            bool isLegalColour = true;
            isLegalColour = Enum.GetNames(typeof(eSituation)).Contains(i_Situation);
            return isLegalColour;
        }

        public void ChangeSituation(string i_Newsituation)
        {
            m_situation = (eSituation)Enum.Parse(typeof(eSituation), i_Newsituation);
        }

        public void ToString()
        {
            StringBuilder VehicleToString = new StringBuilder();
            VehicleToString.Append("Vehicel model - " + m_CurrentVehicle.m_ModelName);
            VehicleToString.Append("Vehicle number - " + m_CurrentVehicle.m_VehicleNumber);
            VehicleToString.Append("Energy source - " + m_CurrentVehicle.m_EnergySource.EnergyType);
            VehicleToString.Append("Wheels amount - " + m_CurrentVehicle.m_WheelsAmount);
            VehicleToString.Append("Wheels producer - " + m_CurrentVehicle.m_WheelsList[0].ProducerName);
            VehicleToString.Append("Wheels current air pressure - " + m_CurrentVehicle.m_WheelsList[0].CurrentAirPressure);
            VehicleToString.Append("Wheels maximum air pressure - " + m_CurrentVehicle.m_WheelsList[0].MaxAirPressure);
            VehicleToString.Append("Energy left - " + m_CurrentVehicle.m_EnergySource.CurrentEnergyAmount);
            VehicleToString.Append("Maximum energy - " + m_CurrentVehicle.m_EnergySource.MaxEnergy);
            VehicleToString.Append("Vehciel owners name - " + m_OwnersName);
            VehicleToString.Append("Vehciel owners number - " + m_PhoneNumber);
            if(this.m_CurrentVehicle is Motorcycle)
            {
                //TODO
            }

        }

    }
}
