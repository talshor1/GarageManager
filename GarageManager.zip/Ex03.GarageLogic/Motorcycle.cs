﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex03.GarageLogic
{

    public class Motorcycle : Vehicle
    {
        public enum eLicenseKind
        {
            A,
            A1,
            A2,
            B,
        }

        protected eLicenseKind m_LicenseKind;
        protected int m_EngineCapacity = 0;

        public Motorcycle(Dictionary<string, string> i_VehicleInfo) : base(i_VehicleInfo)
        {
            this.m_LicenseKind = (eLicenseKind)Enum.Parse(typeof(eLicenseKind), i_VehicleInfo["License kind"]);
            this.m_EngineCapacity = int.Parse(i_VehicleInfo["Engine capacity"]);
        }

        public string LicenseKind
        {
            get
            {
                return this.m_LicenseKind.ToString();
            }
        }

        public int EngineCapacity
        {
            get
            {
                return this.m_EngineCapacity;
            }
        }

        internal static bool LicenseKindCheck(string i_MotorcycleLicenseKind)
        {
            bool isLegalLicense = true;
            isLegalLicense = Enum.GetNames(typeof(Motorcycle.eLicenseKind)).Contains(i_MotorcycleLicenseKind);
            return isLegalLicense;
        }
    }
}
