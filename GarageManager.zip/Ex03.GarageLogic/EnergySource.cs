﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex03.GarageLogic
{
    public class EnergySource
    {
        public enum eEnergyType
        {
            Electricity,
            Soler,
            Octan95,
            Octan96,
            Octan98,
        }

        private eEnergyType m_EnergyType;
        private float m_CurrentEnergyAmount;
        private float m_MaximumEnergy;

        public EnergySource(Dictionary<string, string> i_VehicleInfo)
        {
            m_EnergyType = (eEnergyType)Enum.Parse(typeof(eEnergyType), i_VehicleInfo["Energy source"]);
            m_CurrentEnergyAmount = float.Parse(i_VehicleInfo["Energy left"]);
            m_MaximumEnergy = float.Parse(i_VehicleInfo["Maximum energy"]);
        }

        internal float CurrentEnergyAmount
        {
            get { return m_CurrentEnergyAmount; }
        }

        internal float MaxEnergy
        {
            get { return m_MaximumEnergy; }
        }

        internal eEnergyType EnergyType
        {
            get { return m_EnergyType; }
        }

        internal void RefillEnergy(string i_EnergyType, float i_EnergyToRefill)
        {
            eEnergyType energyType = (eEnergyType)Enum.Parse(typeof(eEnergyType), i_EnergyType);
            if (!energyType.Equals(m_EnergyType))
            {
                throw new ArgumentException("Invalid input. Wrong Energy type value.");
            }

            if (!isValidEnergyToAdd(i_EnergyToRefill))
            {
                throw new ValueOutOfRangeException("Value too big",0, m_MaximumEnergy-m_CurrentEnergyAmount);
            }

            m_CurrentEnergyAmount += i_EnergyToRefill;
        }

        private bool isValidEnergyToAdd(float i_EnergyToRefill)
        {
            bool isValidLitersToAdd = true;

            if (m_CurrentEnergyAmount + i_EnergyToRefill > m_MaximumEnergy)
            {
                isValidLitersToAdd = false;
            }

            return isValidLitersToAdd;
        }

        internal float GetEnergyPercentageLeft()
        {
            return (m_CurrentEnergyAmount / m_MaximumEnergy) * 100;
        }

        public static bool CheckLegalSource(string i_VehicleSource)
        {
            bool isLegalSource = true;
            isLegalSource = Enum.IsDefined(typeof(eEnergyType), i_VehicleSource);
            return isLegalSource;
        }
    }

}