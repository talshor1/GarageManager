﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex03.GarageLogic
{
    public class VehicleInTheGarage
    {
        public static List<Vehicle> m_AllVehicles = new List<Vehicle>();
        public static List<Costumer> m_CustomersInTheGarage = new List<Costumer>();

        public static bool CheckIfVehicleExists(string i_VehicleNumber)
        {
            Boolean VehicleExists = true;
            foreach (Costumer costumer in m_CustomersInTheGarage)
            {
                if (i_VehicleNumber == costumer.m_CurrentVehicle.VehicleNumber)
                {
                    VehicleExists = false;
                    break;
                }

            }

            return VehicleExists;
        }

        public static bool InsertVehicleToGarage(Vehicle i_VehicleToInsert)
        {
            Boolean succeededInserting = true;
            string vehicleToInsertNumber = i_VehicleToInsert.VehicleNumber;
            if(!CheckIfVehicleExists(vehicleToInsertNumber))
            {
                succeededInserting = false;
            }

            else
            {
                Console.WriteLine("please enter you personal name:");
                string vehicleOwnersName = Console.ReadLine();
                Console.WriteLine("please enter your number:");
                string vehicleOwnersNumber = Console.ReadLine();
                if(!GenericValidation.CheckIfIntAndPositive(vehicleOwnersNumber))
                {
                    succeededInserting = false;
                }

                if(vehicleOwnersName == string.Empty)
                {
                    succeededInserting = false;
                }

                Costumer newCostumer = new Costumer(i_VehicleToInsert, vehicleOwnersName, vehicleOwnersNumber);
                m_CustomersInTheGarage.Add(newCostumer);
            }

            return succeededInserting; 
        }

        public static void ShowVehiclesNumbers()
        {
            int vehicleNumber = 1;
            foreach(Costumer costumer in m_CustomersInTheGarage)
            {
                Console.WriteLine(vehicleNumber + ".) " + costumer.m_CurrentVehicle.VehicleNumber);
                vehicleNumber++;
            }
        }

        public static void SituationChange(string i_VehicleNumber, string i_NewSituation)
        {
            foreach(Costumer costumer in m_CustomersInTheGarage)
            {
                if(costumer.m_CurrentVehicle.VehicleNumber == i_VehicleNumber)
                {
                    costumer.ChangeSituation(i_NewSituation);
                }
            }
        }

        public static void InflateMax(string  i_VehicleNumber)
        {
            foreach (Costumer costumer in m_CustomersInTheGarage)
            {
                if (costumer.m_CurrentVehicle.VehicleNumber == i_VehicleNumber)
                {
                    costumer.m_CurrentVehicle.InflateMax();
                }
            }
        }

        public static void ShowVehicleDetails(string i_VehicleNumber)
        {
            foreach (Costumer costumer in m_CustomersInTheGarage)
            {
                if (costumer.m_CurrentVehicle.VehicleNumber == i_VehicleNumber)
                {
                    costumer.m_CurrentVehicle.ToString();
                }
            }

        }

        public static void Refuel(string i_VehicleNumber, string i_EnergyType, string i_Amount)
        {
            foreach(Costumer costumer in m_CustomersInTheGarage)
            {
                if (costumer.m_CurrentVehicle.m_VehicleNumber == i_VehicleNumber)
                {
                    try
                    {
                        costumer.m_CurrentVehicle.AddEnergyToVehicle(i_EnergyType, float.Parse(i_Amount));
                    }
                    catch (Exception e)
                    {
                        throw e;
                    }
                }
            }
        }

    }
}
