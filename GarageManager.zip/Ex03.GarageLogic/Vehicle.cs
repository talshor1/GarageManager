﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex03.GarageLogic
{
    public class Vehicle
    {
        public readonly string m_ModelName = null;
        public readonly string m_VehicleNumber = null;
        public EnergySource m_EnergySource;
        public int m_WheelsAmount;
        public List<Wheel> m_WheelsList;
        public float m_EnergyPercentageLeft;

        protected Vehicle(Dictionary<string, string> i_VehicleInfo)
        {
            m_ModelName = i_VehicleInfo["Model name"];
            m_VehicleNumber = i_VehicleInfo["Vehicle number"];
            m_EnergySource = new EnergySource(i_VehicleInfo);
            m_EnergyPercentageLeft = m_EnergySource.GetEnergyPercentageLeft();
            m_WheelsAmount = int.Parse(i_VehicleInfo["Wheels amount"]);
            m_WheelsList = setWheels(i_VehicleInfo);
        }

        public string VehicleNumber
        {
            get { return this.m_VehicleNumber; }
        }

        private List<Wheel> setWheels(Dictionary<string, string> i_VehicleInfo)
        {
            List<Wheel>o_WheelsList = new List<Wheel>();
            int NumOfWheels = int.Parse(i_VehicleInfo["Wheels amount"]);
            string producerName = i_VehicleInfo["Wheels producer"];

            for (int i = 0; i < NumOfWheels; i++)
            {
                o_WheelsList.Add(new Wheel(i_VehicleInfo));
            }

            return o_WheelsList;
        }

        public void AddEnergyToVehicle(string i_EnergyType, float i_EnergyAmountToAdd)
        {
            m_EnergySource.RefillEnergy(i_EnergyType, i_EnergyAmountToAdd);
        }

        public override bool Equals(object i_Object)
        {
            bool isEquals = false;

            Vehicle vehicleToCompare = i_Object as Vehicle;
            if (vehicleToCompare != null)
            {
                isEquals = (this.m_VehicleNumber == vehicleToCompare.m_VehicleNumber);
            }

            return isEquals;
        }

        public override int GetHashCode()
        {
            return m_VehicleNumber.GetHashCode();
        }

        public void InflateMax()
        {
            Wheel.InflateMax(this.m_WheelsList);
        }

        internal string GetVehicleInfo()
        {
            return "";
        }
    }
}