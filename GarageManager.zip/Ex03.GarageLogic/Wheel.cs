﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex03.GarageLogic
{
    public class Wheel
    {
        private string m_ProducerName = null;
        private float m_CurrentAirPressure = 0f;
        private float m_MaxAirPressure;

        internal Wheel(Dictionary<string, string> i_VehicleDic)
        {
            m_ProducerName = i_VehicleDic["Wheels producer"];
            m_CurrentAirPressure = float.Parse(i_VehicleDic["Wheels current air pressure"]);
            m_MaxAirPressure = float.Parse(i_VehicleDic["Wheels maximum air pressure"]);
        }

        public string ProducerName
        {
            get
            {
                return this.m_ProducerName;
            }
        }

        public float CurrentAirPressure
        {
            get
            {
                return this.m_CurrentAirPressure;
            }
        }
        public float MaxAirPressure
        {
            get
            {
                return this.m_MaxAirPressure;
            }
        }

        internal bool Inflate(float i_AmountToAdd)
        {
            bool isInflateSucceeded = true;

            if (m_CurrentAirPressure + i_AmountToAdd < m_MaxAirPressure)
            {
                m_CurrentAirPressure += i_AmountToAdd;
            }
            else
            {
                isInflateSucceeded = false;
            }

            return isInflateSucceeded;
        }

        public static bool CheckWheelsAmountValidity(string i_VehicleWheelsAmount)
        {
            bool isLegalAmount = true;
            int wheelsAmount = 0;
            try
            {
                wheelsAmount = int.Parse(i_VehicleWheelsAmount);
            }
            catch(Exception e)
            {
                Console.WriteLine("The amount of wheels should be numeric value");
                isLegalAmount = false;
            }

            if(wheelsAmount != 2 && wheelsAmount != 4 && wheelsAmount != 12)
            {
                isLegalAmount = false;
            }

            return isLegalAmount;
        }

        public static void InflateMax(List<Wheel> i_VehicleWheels)
        {
            foreach(Wheel wheel in i_VehicleWheels)
            {
                wheel.m_CurrentAirPressure = wheel.m_MaxAirPressure;
            }
        }

    }
}